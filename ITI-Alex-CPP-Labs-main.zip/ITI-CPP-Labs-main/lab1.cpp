#include <iostream.h>
#include <conio.h>
#include <stdio.h>
void main<>{
    int x , y;
    cout << "Enter First Number:";
    cin >> x;
    cout << "Enter Second Number:";
    cin >> y;
    cout << "Sum =" << x + y;
    getchar();
    clrscr();
}


#include <iostream.h>
int main(){
    int x, y;
    cout << "Enter First Number : ";
    cin >> x; 
    cout << "Enter Second Number : ";
    cin >> y;
    cout << "Sum :" << x + y;
    return 0;
}




/*
Alt + f9 ==> for compiling 
Ctrl + f9 ==> to run the code 
Alt + f5 ==> to see the output
*/
